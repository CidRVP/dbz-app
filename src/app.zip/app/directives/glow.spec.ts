import { Glow } from './glow';

describe('Glow', () => {
  it('should create an instance', () => {
    const directive = new Glow();
    expect(directive).toBeTruthy();
  });
});
