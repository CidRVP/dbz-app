import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';

import { DbzService, DragonBallCharacter } from '../services/dbz.service';
import { PowerLevelPipe } from '../pipes/power-level-pipe';
import { GlowDirective } from '../directives/glow.directive';

@Component({
  selector: 'app-character-details',
  templateUrl: 'character-details.page.html',
  styleUrls: ['character-details.page.scss'],
  standalone: true,
  imports: [
    IonicModule, 
    CommonModule,
    PowerLevelPipe,
    GlowDirective
  ]
})
export class CharacterDetailsPage implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private dbzService = inject(DbzService);

  character: DragonBallCharacter | null = null;
  loading = false;
  error: string | null = null;

  ngOnInit() {
    const characterId = this.route.snapshot.paramMap.get('id');
    
    if (characterId) {
      this.loadCharacterDetails(parseInt(characterId));
    } else {
      this.error = 'ID do personagem não encontrado';
    }
  }

  loadCharacterDetails(id: number) {
    this.loading = true;
    this.error = null;

    this.dbzService.getCharacterById(id).subscribe({
      next: (character) => {
        this.character = character;
        this.loading = false;
      },
      error: (err) => {
        this.error = err.message;
        this.loading = false;
      }
    });
  }

  getRaceColor(race: string): string {
    const raceColors: { [key: string]: string } = {
      'Saiyan': 'danger',
      'Human': 'primary',
      'Namekian': 'success',
      'Frieza Race': 'warning',
      'Android': 'medium',
      'God': 'tertiary'
    };
    
    return raceColors[race] || 'secondary';
  }

  getPowerLevelColor(ki: string): string {
    const power = parseInt(ki);
    if (power > 1000000) return 'danger';
    if (power > 100000) return 'tertiary';
    if (power > 50000) return 'warning';
    if (power > 10000) return 'success';
    return 'primary';
  }

  goBack() {
    this.router.navigate(['/']);
  }
}