import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'powerLevel',
  standalone: true
})
export class PowerLevelPipe implements PipeTransform {
  transform(value: string): string {
    if (!value) return 'Desconhecido';
    
    const power = parseFloat(value);
    if (isNaN(power)) return 'Desconhecido';
    
    // Formata o número para mostrar completo
    if (power >= 1000000) {
      return `LENDÁRIO (${this.formatNumber(power)})`;
    }
    if (power >= 100000) {
      return `ULTRA INSTINTO (${this.formatNumber(power)})`;
    }
    if (power >= 50000) {
      return `SUPER SAIYAJIN GOD (${this.formatNumber(power)})`;
    }
    if (power >= 10000) {
      return `SUPER SAIYAJIN 3 (${this.formatNumber(power)})`;
    }
    if (power >= 1000) {
      return `SUPER SAIYAJIN (${this.formatNumber(power)})`;
    }
    
    return `NORMAL (${this.formatNumber(power)})`;
  }

  private formatNumber(num: number): string {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }
}