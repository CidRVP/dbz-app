import { PowerLevelPipe } from './power-level-pipe';

describe('PowerLevelPipe', () => {
  it('create an instance', () => {
    const pipe = new PowerLevelPipe();
    expect(pipe).toBeTruthy();
  });
});
